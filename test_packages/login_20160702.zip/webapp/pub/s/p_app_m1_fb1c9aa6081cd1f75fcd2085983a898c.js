var c = 'cccccccccccc';
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
// this is comment
console.log('lib from c.js')
var d = 'dddddddddd';
console.log('lib from d.js')